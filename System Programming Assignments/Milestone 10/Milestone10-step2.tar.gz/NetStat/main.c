#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "netstat.h"


void write_net(struct net_stat *stat);

int main (int argc, const char *argv[])
{
	struct net_stat stat;

	// if (get_net_statistics(&stat) == -1)
	// {
	// 	perror("cannot get net statistics");
	// 	return EXIT_FAILURE;
	// }

	// printf("Total packets that went over the %s network interface: %d\n",
	//        stat.name, stat.in_packets + stat.out_packets);
	// printf("Errors: %d / %d\n", stat.in_errors, stat.out_errors);
	// printf("MTU: %d\n", stat.mtu);

	write_net(&stat);

	return EXIT_SUCCESS;
}

// FUNCTION write_net
// function that update a netstat struct once per second and writes current network status into it.
void write_net(struct net_stat *stat)
{
	while(1)
	{
		sleep(1);
		//Get current net stats
		if (get_net_statistics(stat) == -1)
		{
			perror("cannot get net statistics");
			exit(1);
		}
	}
}
