#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <ctype.h>
#include <stdint.h>
#include "queue.h"

typedef struct thread_args 
{  
	struct Queue queue;
} t_args;

void *produce_num(void*);

int main(int argsc, char *argsv[])
{
	pthread_t producer_thread;
	t_args targs;

	int max_size = 4;
	int min_size = 0;

	queue_initialise(&targs.queue, max_size, min_size);

	while(1)
	{
		//Produce random numbers
		if(pthread_create(&producer_thread, NULL, *produce_num, (void *) &targs))
		{
			printf("%s Thread creation failed. \n", "producer_thread");
			exit(1);
		}
		if(pthread_join(producer_thread, NULL))
		{
			printf("%s Thread join failed. \n", "producer_thread");
			exit(1);
		}
	}
}

void *produce_num(void* ptr)
{
	t_args* args;
    args = (t_args*) ptr;
	//Read /dev/random
	FILE* file = fopen("/dev/random", "r");

    for(int i = 0; i < 10; i++)
    {
		uint64_t rand;
		fread(&rand, sizeof(rand), 1, file);
		printf("random number is : %llx \n", (unsigned long long)rand);
		put_buffer(&args->queue, rand);
    }
	fclose(file);
	pthread_exit(NULL);
}