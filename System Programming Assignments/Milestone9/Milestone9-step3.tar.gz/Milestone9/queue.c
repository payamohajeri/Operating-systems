#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdint.h>
#include "queue.h"

void queue_initialise(struct Queue* queue, int max_val, int min_val)
{
	queue->buff = malloc(sizeof(uint64_t*)*max_val);
    queue->max = max_val;
    queue->min = min_val;
    queue->top_index = 0;
    queue->bottom_index = 0;
    queue->count = 0;
}

void queue_cleanup(struct Queue* queue)
{
    queue->max = 0;
    queue->min = 0;
    queue->top_index = 0;
    queue->bottom_index = 0;
    queue->count = 0;
}

void put_buffer(struct Queue* queue, uint64_t rand_val)
{
    
    // Add random value to the queue buffer
    queue->buff[queue->top_index] = rand_val;
    queue->top_index++;
       
    // Reset buffer once queue max is reached
    if(queue->top_index == queue->max)
        queue->top_index = 0;
    
    queue->count++;
}