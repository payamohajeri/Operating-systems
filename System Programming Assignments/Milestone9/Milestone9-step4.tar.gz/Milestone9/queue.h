#ifndef queue_h
#define queue_h

struct Queue
{
	uint64_t* buff;
    int top_index;
    int bottom_index;
    int max;
    int min;
    int count;
};

void queue_initialise(struct Queue*, int, int);
void queue_cleanup(struct Queue*);
void put_buffer(struct Queue*, uint64_t);
void queue_cleanup(struct Queue*);

#endif