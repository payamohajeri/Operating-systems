#ifndef queue_h
#define queue_h

struct Queue
{
	uint64_t* buff;
    int max;
    int min;
};

void queue_initialise(struct Queue*, int, int);
void queue_cleanup(struct Queue*);

#endif