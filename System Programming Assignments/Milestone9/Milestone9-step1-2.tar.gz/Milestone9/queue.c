#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdint.h>
#include "queue.h"

void queue_initialise(struct Queue* queue, int max_val, int min_val)
{
	queue->buff = malloc(sizeof(uint64_t*)*max_val);
    queue->max = max_val;
    queue->min = min_val;
}

void queue_cleanup(struct Queue* queue)
{}